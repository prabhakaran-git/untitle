import re
import subprocess
import time
from tools.python.utilities.common import is_darwin, is_windows

mac_network_port = 'en0'  # defaulting to port en0 which is a Wi-Fi port on latest MACs. However this will be replaced in the turn off function accordinlgy.


def turn_computer_network(status):
    # status can be either ON or OFF . This keyword takes care of turning on/off network accrodingly
    if status == 'ON':
        __turn_computer_network_on()
    elif status == 'OFF':
        __turn_computer_network_off()
    else:
        raise Exception('Please input the status either ON or OFF')


def __turn_computer_network_off():
    try:
        if is_darwin():
            global mac_network_port
            # Below command is to get the active network port on MAC.
            process = subprocess.run('route get example.com | grep interface', shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT)
            stdout = str(process.stdout)
            # interface = process.interface
            stderr = process.returncode
            port = stdout.split(' ')
            port = port[3]
            if 'bad address' in stdout:
                flag = False
            else:
                flag = True
            print('WiFi/Network port is already disabled')
            if flag:
                port = re.sub(r"\W", "", port)
                port = port[:-1]
                mac_network_port = port  # obtain the network port from stdout.
                command = 'sudo ifconfig {} down'.format(port)
                process1 = subprocess.run(command.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                # process1.communicate()
        elif is_windows():
            command1 = 'netsh interface set interface Wi-Fi disable'
            command2 = 'netsh interface set interface Ethernet disable'
            process = subprocess.run(command1.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout = str(process.stdout)
            stderr = process.returncode
            print(stderr)
            process = subprocess.run(command2.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout = str(process.stdout)
            stderr = process.returncode
            print(stderr)
        assert __validate_network_connection('host'), 'Failure : Network connection could not be turned off..'
        return True
    except:
        print("something went wrong ......")
        assert False, 'Failure : Something is Wrong. Error: {}'.format(stderr)


def __turn_computer_network_on():
    try:
        if is_darwin():
            command = 'sudo ifconfig {} up'.format(mac_network_port)
            process = subprocess.run(command.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            # process.communicate()
        elif is_windows():
            command1 = 'netsh interface set interface Wi-Fi enable'
            command2 = 'netsh interface set interface Ethernet enable'
            process = subprocess.run(command1.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout = str(process.stdout)
            stderr = process.returncode
            print(stdout)
            print(stderr)
            process = subprocess.run(command2.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout = str(process.stdout)
            stderr = process.returncode
            print(stdout)
            print(stderr)
        time.sleep(10)
        assert __validate_network_connection('bytes'), 'Failure : Network connection could not be turned on..'
        return True
    except:
        assert False, 'Failure : Something is Wrong. Error: {}'.format(stderr)


def __validate_network_connection(match_string_in_stdout):
    if is_darwin():
        command = 'ping example.com -t 5'
    else:
        command = 'ping example.com'
    process = subprocess.run(command.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout = str(process.stdout)
    stderr = process.returncode
    print(stdout)
    print(stderr)
    if match_string_in_stdout in stdout:
        return True
    else:
        print('The network state has not changed as expected...!!. Please check you are connected to either Wi-Fi or Ethernet, not both.')
        return False
