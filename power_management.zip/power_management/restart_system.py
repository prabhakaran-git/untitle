# Due to the limitation of robot framework sys.argv, it doesn't contain any options like '--listener'
# The command has to saved in runtest.bat or runtest.sh file for the keyword to get the command line
# next_test=-t "after restart": can be either test case or test suite
# The test cases run after restart should be in the same folder or robot file as put in the command
# When run on Mac, make sure to run sudo visudo to turn off password when run 'shutdown' command

from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import platform
from builtins import int
from builtins import open
from builtins import str
import re

import tools.python.utilities.process as process

from future import standard_library
standard_library.install_aliases()


if platform.system() == 'Windows':
    import winreg as reg
if platform.system() == 'Darwin':
    import plistlib
    import sys

if platform.system() == 'Windows':
    # system shutdown path
    SHUTDOWN_TOOL_WIN_PATH = os.environ['WINDIR'] + "\\System32\\" + 'shutdown.exe'
    RUNONCE_KEY = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
    CMD_FILENAME = "runtest.bat"


if platform.system() == 'Darwin':
    PLIST_FILE = os.path.expanduser("~") + "/Library/LaunchAgents/com.logitech.lego.plist"
    SCRIPT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../../run_test.py')
    TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_template.py')
    CMD_FILENAME = "runtest.sh"

# drone.py path
DRONE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../..')
# count value saved in the same folder record.txt file
RECORD_PATH = os.path.dirname(os.path.realpath(__file__)) + '/record.txt'
CMD_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),'../../../../') + CMD_FILENAME
AFTERREBOOT_FILE = os.path.dirname(os.path.realpath(__file__)) + "\\runtest_afterreboot.bat"


def restart_system(**kwargs):
    print ("in function")
    loop = None
    next_test = None
    count = None

    for key, value in list(kwargs.items()):
        if key == 'loop':
            loop = int(value)
        elif key == 'next_test':
            next_test = str(value)

    if not loop:
        print (" No loop number, only restart once. ")
        restart(next_test)
    else:
        if os.path.isfile(RECORD_PATH):
            # file exists, read current value
            try:
                record_file = open(RECORD_PATH, "r")
                count = record_file.read()
                record_file.close()
            except OSError as e:  # if failed, report it back to the user #
                print(("Error: {} - {}.".format(e.filename, e.strerror)))
            # subtract one
            assert int(count), 'Failure: restart count can not be read'
            count = int(count) - 1

            # write to file
            try:
                record_file = open(RECORD_PATH, "w+")
                record_file.write(str(count))
                record_file.close()
            except OSError as e:  # if failed, report it back to the user #
                print(("Error: {} - {}.".format(e.filename, e.strerror)))
            print(('number {} write to file'.format(count)))
        else:
            try:
                # file doesn't exist, create file
                record_file = open(RECORD_PATH, "w+")
                # write record into file
                record_file.write(str(loop))
                # close file
                record_file.close()
            except OSError as e:  # if failed, report it back to the user #
                print(("Error: {} - {}.".format(e.filename, e.strerror)))
            count = int(loop)

        if count > 0:
            print(("{} counts of restart left".format(count)))
            restart(next_test)
        else:
            cleanup()


def restart(next_test=None):
    if next_test:
        the_test = get_new_cmd(next_test)
        if platform.system() == 'Windows':
            set_on_windows(the_test)
        elif platform.system() == 'Darwin':
            set_on_mac(the_test)

    launch_shutdown()


def launch_shutdown():
    if platform.system() == 'Windows':
        process.launch(SHUTDOWN_TOOL_WIN_PATH, False, False, '-r', '-t', '10')
    elif platform.system() == 'Darwin':
        print ("before restart")
        process.launch('sudo', False, False, 'shutdown', '-r', '+1')
        # theprocess = subprocess.Popen(
        #     ['sudo', 'shutdown', '-r', '+1'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        # stdout, stderr = theprocess.communicate()
        # print(stderr)
        # print((stdout.replace('\r', '')))
        print("after restart")

        # if not theprocess.returncode == 0:
        #     print(("WARNING:  Command returns non-zero return code: {return_code}".format(return_code=process.returncode)))

    return


def cleanup():
    # delete count file
    try:
        print("Remove file")
        os.remove(RECORD_PATH)
        os.remove(AFTERREBOOT_FILE)
    except OSError as e:  # if failed, report it back to the user #
        print(("Error: {} - {}.".format(e.filename, e.strerror)))

    if platform.system() == 'Darwin':
        try:
            # delete plist and test.py file
            os.remove(PLIST_FILE)
            os.remove(SCRIPT_PATH)
        except OSError as e:  # if failed, report it back to the user #
            print(("Error: {} - {}.".format(e.filename, e.strerror)))

def get_new_cmd(next_test):
    cmd = []
    # read command and saved into a list
    try:
        data = open(CMD_FILE, "r").read()
    except OSError as e:
        print(("Error: {} - {}.".format(e.filename, e.strerror)))
    cmd = re.findall(r'(?:[^\s,"]|"(?:\\.|[^"])*")+', data)

    the_test = ""
    if 'drone' in str(cmd):
        # It's drone command
        the_test = r"python " + DRONE_PATH + "/drone.py run:test --" + next_test  # eg. python <path>drone.py run:test --case="<test case name>"
    else:
        passindex = 0
        insertindex = 0
        for index, value in enumerate(cmd):
            if passindex == index or value == "":
                pass
            elif value.lower() == '-s' or value.lower() == '--suite':
                cmd[index] = ""
                cmd[index + 1] = ""
            elif value.lower() == '-t' or value.lower() == '--test' or value.lower() == '--task':
                cmd[index] = ""
                cmd[index + 1] = ""
            elif '-' in value:
                # keep options other than '-t' and '-s'
                passindex = index + 1
            else:
                if insertindex == 0:
                    insertindex = index

    if the_test == "":
        # build the command line for after reboot
        for index in range(0, len(cmd)):
            if index == insertindex:
                the_test = the_test + next_test + " "
            if (cmd[index] != ""):
                the_test = the_test + cmd[index] + " "
    print(the_test)
    return the_test


if platform.system() == 'Windows':
    def set_on_windows(the_test):

        # save command to batchfile
        try:
            script_file = open(AFTERREBOOT_FILE, 'w')
            script_file.write("cd " + DRONE_PATH + "\n" + the_test + "\npause")
            script_file.close()
        except OSError as e:  # if failed, report it back to the user #
            print(("Error: {} - {}.".format(e.filename, e.strerror)))

        # add next_test in registry runonce key
        reg_set_value(reg.HKEY_CURRENT_USER, RUNONCE_KEY, "zeResume Automation", reg.REG_SZ, AFTERREBOOT_FILE)
        print("set RunOnce key")


    def reg_set_value(key, reg_subkey, name, reg_type, value):
        try:
            root_key = reg.OpenKey(key, reg_subkey, 0, reg.KEY_ALL_ACCESS)
            reg.SetValueEx(root_key, name, 0, reg_type, value)
            reg.CloseKey(root_key)
            return True
        except WindowsError as e:
            print(("Error: {} - {}.".format(e.filename, e.strerror)))
            return False


if platform.system() == 'Darwin':
    def set_on_mac(the_test):
        if not os.path.isfile(PLIST_FILE):
            # create plist
            create_plist()
            # update test.py
            update_file(the_test)


    def create_plist():
        python_path = sys.executable

        pl = {
            "Label": "com.logitech.drone",
            "Program": python_path,
            "ProgramArguments": [python_path, SCRIPT_PATH],
            "RunAtLoad": True
        }
        try:
            plistlib.writePlist(pl, PLIST_FILE)
        except OSError as e:  # if failed, report it back to the user #
            print(("Error: {} - {}.".format(e.filename, e.strerror)))


    def update_file(next_test):

        try:
            template_file = open(TEMPLATE_PATH, 'r')
            filedata = template_file.read()
            template_file.close()
        except OSError as e:  # if failed, report it back to the user #
            print(("Error: {} - {}.".format(e.filename, e.strerror)))

        # add double slash for test case or test suit name
        the_next_test = next_test.replace("\"", "\\\\\"")

        try:
            newdata = filedata.replace("%__next_test_cmd__%", the_next_test)
            finaldata = newdata.replace("%__dir__%", DRONE_PATH)
        except OSError as e:  # if failed, report it back to the user #
            print(("Error: {} - {}.".format(e.filename, e.strerror)))

        try:
            script_file = open(SCRIPT_PATH, 'w')
            script_file.write(finaldata)
            script_file.close()
        except OSError as e:  # if failed, report it back to the user #
            print(("Error: {} - {}.".format(e.filename, e.strerror)))
