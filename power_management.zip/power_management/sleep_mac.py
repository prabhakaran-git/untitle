import os
import subprocess

SUSPEND_TOOL_MAC_PATH = os.path.dirname(os.path.realpath(__file__)) + '/suspend_tool'


def mac_sleep(**params):
    process = subprocess.run(['sudo', SUSPEND_TOOL_MAC_PATH, str(params.get('sleep_time')),  str(params.get('delay')), str(params.get('cycles'))], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout = str(process.stdout)
    stderr = process.returncode
    print(stderr)
    print((stdout.replace('\r', '')))

    if not process.returncode == 0:
        print(("WARNING:  Command returns non-zero return code: {return_code}".format(return_code=process.returncode)))


def mac_sleep_old(sleep_duration=60, wake_duration=60, num_cycles=1):
    process = subprocess.run(['sudo', SUSPEND_TOOL_MAC_PATH, str(sleep_duration),  str(wake_duration), str(num_cycles)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout = str(process.stdout)
    stderr = process.returncode
    print(stderr)
    print((stdout.replace('\r', '')))

    if not process.returncode == 0:
        print(("WARNING:  Command returns non-zero return code: {return_code}".format(return_code=process.returncode)))

