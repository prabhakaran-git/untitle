In terminal, run 'sudo visudo' to open the sudoers file
Add these two lines to the file, change 'username' and 'pathto' to match your specific configuration:

username ALL=(ALL) NOPASSWD: /pathto/gerty/tools/python/mindstorm/power_management/sleep_mac.py
username ALL=(ALL) NOPASSWD: /pathto/gerty/tools/python/mindstorm/power_management/suspend_tool

e.g.

tnguyen ALL=(ALL) NOPASSWD: /Users/tnguyen/Documents/gerty/tools/python/mindstorm/power_management/sleep_mac.py
tnguyen ALL=(ALL) NOPASSWD: /Users/tnguyen/Documents/gerty/tools/python/mindstorm/power_management/suspend_tool

On Mac (Catalina), manually launch 'sudo pmset sleepnow' (sudo pmset displayleepnow) once before using it in your test.