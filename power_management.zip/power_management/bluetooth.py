# Ensure to install blueutil on MAC by using the command: <brew install blueutil>
import subprocess
from tools.python.utilities.common import is_darwin, is_windows


def turn_computer_bluetooth(status):
    # status can be either ON or OFF . This keyword takes care of turning on/off bluetooth accrodingly
    if status == 'ON':
        __turn_computer_bluetooth_on()
    elif status == 'OFF':
        __turn_computer_bluetooth_off()
    else:
        raise Exception('Please input the status either ON or OFF')


def __turn_computer_bluetooth_off():
    try:
        if is_darwin():
            command = 'blueutil -p 0'
        else:
            command = 'net stop bthserv'
        # process = subprocess.Popen(command.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT).decode('utf-8')
        process = subprocess.run(command.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout = str(process.stdout)
        stderr = process.returncode
        if is_darwin() and 'command not found' in stdout:
            flag = False
        elif is_windows() and ('stopping' in stdout or 'not started' in stdout):
            flag = True
        elif is_darwin() and 'b\'\'' in stdout:
            flag = True
        else:
            flag = False
        assert flag, 'Failure : \n If on MAC :  Check if blueutil is installed. You can install by using thecommand <brew install blueutil> \n If on Windows: Bluetooth service could not be stopped...something is wrong'
        print(stdout)
        print(stderr)
        return True
    except:
        print("Could not stop the bluetooth service !! something went wrong ......")
        assert False, 'Failure : Something is Wrong. Error: {}'.format(stderr)  # Local variable 'stderr' might be referenced before assignment


def __turn_computer_bluetooth_on():
    try:
        if is_darwin():
            command = 'blueutil -p 1'
        else:
            command = 'net start bthserv'
        process = subprocess.run(command.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout = str(process.stdout)
        stderr = process.returncode
        if is_darwin() and 'command not found' in stdout:
            flag = False
        elif is_windows() and 'starting' in stdout:
            flag = True
        elif is_darwin() and 'b\'\'' in stdout:
            flag = True
        else:
            flag = False
        assert flag, 'Failure : \n If on MAC :  Check if blueutil is installed. You can install by using thecommand <brew install blueutil> \n If on Windows: Bluetooth service could not be stopped...something is wrong'
        print(stdout)
        print(stderr)
        return True
    except:
        print("Could not start the bluetooth service !! something went wrong ......")
        assert False, 'Failure : Something is Wrong. Error: {}'.format(stderr)  # Local variable 'stderr' might be referenced before assignment
