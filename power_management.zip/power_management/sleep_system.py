from tools.python.utilities import is_darwin, is_windows


if is_windows():
	from tools.python.mindstorm.power_management.sleep_windows import *
if is_darwin():
	from tools.python.mindstorm.power_management.sleep_mac import *


def sleep_system(**params):
	if is_windows():
		windows_sleep(**params)
	if is_darwin():
		mac_sleep(**params)
