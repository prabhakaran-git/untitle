import os
import subprocess
import time
from tools.python.utilities import *

if is_windows():
    import win32com.shell.shell as shell  # Module 'shell' not found
    import win32event


PWRTEST_PATH = os.path.dirname(os.path.realpath(__file__)) + '/pwrtest.exe'
PWRTEST_SHORTCUT_PATH = os.path.dirname(os.path.realpath(__file__)) + '/pwrtest_shortcut.lnk'
PWRTEST_LOG_PATH = os.path.abspath(os.getcwd()) + '/report'  # Note: /lf param does not write logs in PWRTEST_LOG_PATH, not sure why
BATCHFILE_PATH = os.path.dirname(os.path.realpath(__file__)) + '/try_sleep.bat'


def windows_sleep_after_restart(**params):
    print(PWRTEST_LOG_PATH)
    cmd_line = " ".join(("{}={}".format(*i) for i in sorted(params.items())))
    cmd_line = cmd_line.replace('sleep_states=', '/s:').replace('sleep_time=', '/p:').replace('cycles=', '/c:').replace('delay=', '/d:').replace('timeout=', '/e:')
    cmd_line = cmd_line + ' /lf:{log_path}'.format(log_path=PWRTEST_LOG_PATH.replace('\\', '/'))

    # to workaround the elevated requirement for sleep tool
    # launch elevated shortcut which runs a batch file that can launch pwrtest.exe for sleep
    # Create batch file
    if os.path.isfile(BATCHFILE_PATH):
        os.remove(BATCHFILE_PATH)
        assert not os.path.isfile(BATCHFILE_PATH), 'Failure: system can not delete the batch file'
    the_file = open(BATCHFILE_PATH, "w")
    str = PWRTEST_PATH + ' /sleep ' + cmd_line
    the_file.write(str)
    the_file.close()
    assert os.path.isfile(BATCHFILE_PATH),  'Failure: system can not create the batch file'

    # launch and wait
    se_ret = shell.ShellExecuteEx(fMask=0x140, lpFile=PWRTEST_SHORTCUT_PATH, nShow=1)
    win32event.WaitForSingleObject(se_ret['hProcess'], -1)

    # clean up
    if os.path.isfile(BATCHFILE_PATH):
        os.remove(BATCHFILE_PATH)
        assert not os.path.isfile(BATCHFILE_PATH), 'Failure: system can not delete the batch file'

def windows_sleep(**params):
    print(PWRTEST_LOG_PATH)

    command = ''.join([PWRTEST_PATH, ' /sleep',
                                ' /s:'+params['sleep_states'] if params.get('sleep_states') is not None else ' /s:3',
                                ' /p:'+str(params['sleep_time']) if params.get('sleep_time') is not None else ' /p:90',
                                ' /c:'+params['cycles'] if params.get('cycles') is not None else ' /c:1',
                                ' /d:'+params['delay'] if params.get('delay') is not None else ' /d:90',
                                ' /e:'+params['timeout'] if params.get('timeout') is not None else ' /e:120',
                                ' /lf:{log_path}'.format(log_path=PWRTEST_LOG_PATH.replace('\\', '/'))])
    invoke(command, automation=True)


def windows_sleep_async(**params):
    print(PWRTEST_LOG_PATH)

    process = subprocess.Popen([PWRTEST_PATH, '/sleep',
                                '/s:'+params['sleep_states'] if params.get('sleep_states') is not None else '/s:3',
                                '/p:'+params['sleep_time'] if params.get('sleep_time') is not None else '/p:90',
                                '/c:'+params['cycles'] if params.get('cycles') is not None else '/c:1',
                                '/d:'+params['delay'] if params.get('delay') is not None else '/d:90',
                                '/e:'+params['timeout'] if params.get('timeout') is not None else '/e:120',
                                '/lf:{log_path}'.format(log_path=PWRTEST_LOG_PATH.replace('\\', '/'))],

                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout = str(process.stdout)
    stderr = process.returncode
    print(stderr)
    print((stdout.replace('\r', '')))

    if not process.returncode == 0:
        print(("WARNING:  Command returns non-zero return code: {return_code}".format(return_code=process.returncode)))


def windows_sleep_not_used(sleep_states=None, sleep_time=None, cycles=None, delay=None, timeout=None):
    from subprocess import Popen
    # /s = sleep states (1, 3, 4, hibernate, standby, all, rnd), /p = sleep time (in seconds), /c = number of cycles, /d = delay (in seconds), /e = timeout
    if sleep_states is None:
        Popen([PWRTEST_PATH, '/sleep', '/s:3', '/p:120', '/c:1', '/d:150', '/e:90'])
    else:
        Popen([PWRTEST_PATH, '/sleep', '/s:'+sleep_states, '/p:'+sleep_time, '/c:'+cycles, '/d:'+delay, '/e:'+timeout])
    time.sleep(60)
