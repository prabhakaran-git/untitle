import subprocess
import time

from future import standard_library
standard_library.install_aliases()


proc = subprocess.Popen("""osascript -e 'tell app "Terminal"
         do script "sleep 30 && cd %__dir__% && %__next_test_cmd__%"
    end tell'""", stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

time.sleep(10)
